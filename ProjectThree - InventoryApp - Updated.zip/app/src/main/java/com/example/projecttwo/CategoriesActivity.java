/*
Copyright 2024 Stanislav Kovalchuk
Inventory app, Version 1.1

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This activity is used to manage (add/edit/delete) and view categories
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

package com.example.projecttwo;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

/*
* New enhancement for milestone 5-2
*/
public class CategoriesActivity extends AppCompatActivity {
    private DBManager dbManager;
    private LinearLayout categoriesTable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        categoriesTable = findViewById(R.id.categoriesTable);

        //Open database connection
        dbManager = new DBManager(this);
        dbManager.Open();

        RefreshCategories();
    }

    private void InsertCategoryToTable(String id, String name){
        View view = AppViewsGenerator.CreateCategoryView(this, id, name);
        categoriesTable.addView(view);
    }

    private void ClearLayout(){
        int totalViews = categoriesTable.getChildCount();
        if(totalViews > 0) {
            categoriesTable.removeViews(0,totalViews);
        }
    }

    private void RefreshCategories() {

        //First clear layout from previous categories
        ClearLayout();

        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_CATEGORIES, new String[]{});
        int totalCategories = cursor.getCount();
        for (int i = 0; i < totalCategories; i++) {

            String categoryId = cursor.getString(0);
            String categoryName = cursor.getString(1);

            InsertCategoryToTable(categoryId, categoryName);

            cursor.moveToNext();
        }
    }


    public void ShowEditCategory(View view, String categoryId) {

        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_CATEGORIES + " WHERE id = ?", new String[]{categoryId});
        if(cursor.getCount() > 0) {
            String catName = cursor.getString(1);

            final Dialog dialog = new Dialog(this, R.style.addEditProductDlgStyle);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setCancelable(true);
            dialog.setContentView(R.layout.add_edit_category_dialog);


            TextView title = dialog.findViewById(R.id.addEditProductTitle);
            TextView nameView = (TextView)dialog.findViewById(R.id.editItemName);

            Button btnSave = dialog.findViewById(R.id.btnSaveItem);
            Button btnCalncel = dialog.findViewById(R.id.btnEditItemCancel);

            title.setText("Edit Category");
            nameView.setText(catName);

            btnCalncel.setOnClickListener((v)->{
                dialog.dismiss();
            });

            btnSave.setOnClickListener((v)->{
                OnSaveCategory(dialog, categoryId);
                dialog.dismiss();
            });

            dialog.show();

        }
        else {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Category not found").setPositiveButton(R.string.ok, null).show();
        }
    }

    public void ShowAddNewCategory(View view) {
        final Dialog dialog = new Dialog(this, R.style.addEditProductDlgStyle);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.add_edit_category_dialog);

        TextView title = dialog.findViewById(R.id.addEditProductTitle);
        Button btnSave = dialog.findViewById(R.id.btnSaveItem);
        Button btnCalncel = dialog.findViewById(R.id.btnEditItemCancel);
        title.setText("Add New Category");


        btnCalncel.setOnClickListener((v)->{
            dialog.dismiss();
        });

        btnSave.setOnClickListener((v)->{
            OnSaveCategory(dialog, "");
            dialog.dismiss();
        });

        dialog.show();
    }


    public void OnSaveCategory(Dialog context, String categoryId) {
        String categoryName = ((TextView)context.findViewById(R.id.editItemName)).getText().toString();

        if(categoryName.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter category name").setPositiveButton(R.string.ok, null).show();
        }
        else {
            Map<String, String> values = new HashMap<String, String>();
            values.put("name", categoryName);

            // if the categoryId is empty, then it is a new category
            if(categoryId.isEmpty()) {
                dbManager.Insert(DBHelper.TABLE_CATEGORIES, values);
            }
            else {
                dbManager.Update(DBHelper.TABLE_CATEGORIES, categoryId, values);
            }

            //Refresh categories list after Insert/Update
            RefreshCategories();
        }
    }

    public void DeleteCategory(View v, String categoryId){
        // Show prompt dialog if user wants delete the category, if he clicks "yes", the we delete the category
        new AlertDialog.Builder(this)
                .setTitle("Deleting category")
                .setMessage("Are you sure you want to delete this category?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dbManager.Delete(DBHelper.TABLE_CATEGORIES, categoryId);
                        RefreshCategories();
                    }
                })
                .setNegativeButton(android.R.string.no, null)
                .show();
    }

    public void GoToInventoryActivity(View v){
        Intent intent = new Intent(this, InventoryActivity.class);
        startActivity(intent);
    }

}
