/*
Copyright 2024 Stanislav Kovalchuk
Inventory app, Version 1.1

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This activity is used to create and SMS dialog if product quantity is less or zero
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

package com.example.projecttwo;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.HashMap;
import java.util.Map;

public class SMSDialog extends DialogFragment {
    private DBManager dbManager;

    public SMSDialog(InventoryActivity inventoryActivity) {
        dbManager = new DBManager(inventoryActivity);
        dbManager.Open();
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("App SMS permission confirmation");
        builder.setMessage("The Inventory App SMS feature requires permissions to notified for items with zero inventory. You can disable or enable this feature at any time.");
        builder.setNegativeButton("Disable", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Map<String, String> values = new HashMap<String, String>();
                values.put("allowed", "false");
                dbManager.Update(DBHelper.TABLE_SMS_PERMISSIONS, "", values);
            }
        });
        builder.setPositiveButton("Enable",  new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Map<String, String> values = new HashMap<String, String>();
                values.put("allowed", "true");
                dbManager.Update(DBHelper.TABLE_SMS_PERMISSIONS, "", values);
            }
        });

        return builder.create();
    }
}
