/*
Copyright 2024 Stanislav Kovalchuk
Inventory app, Version 1.1

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This class is used to execute queries to the database, such as Insert/Delete/Update/Select
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.Map;

public class DBManager {
    private DBHelper dbHelper;
    private final Context context;
    private SQLiteDatabase db;

    public DBManager(Context c) {
        context = c;
    }

    public void Open() throws SQLException{
        dbHelper = new DBHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public void Close() {
        dbHelper.close();
    }

    //This method will return the last inserted ID
    public long Insert(String tableName, Map<String, String> values){
        ContentValues contentValues = new ContentValues();
        values.forEach(contentValues::put);
        return db.insert(tableName, null, contentValues);
    }

    public Cursor Fetch(String request, String[] cols) {
        Cursor cursor = db.rawQuery(request, cols);
        if(cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public void Update(String tableName, String id, Map<String, String> values) {
        ContentValues contentValues = new ContentValues();
        values.forEach(contentValues::put);
        db.update(tableName, contentValues, id.length() > 0 ? "id=" + id : null, null);
    }

    public void Delete(String tableName, String id)
    {
        db.delete(tableName, "id=" + id, null);
    }
}
