/*
Copyright 2024 Stanislav Kovalchuk
Inventory app, Version 1.1

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This class is used to update or create the database
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/


package com.example.projecttwo;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashMap;
import java.util.Map;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "projectThreeDB";

    private static final int DB_VERSION = 5;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_INVENTORY = "inventory";
    public static final String TABLE_CATEGORIES = "categories";
    public static final String TABLE_SMS_PERMISSIONS = "smsPermissions";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Users table
        {
            String query = "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, password TEXT NOT NULL)";
            db.execSQL(query);
        }

        //Inventory table
        {
            String query = "CREATE TABLE IF NOT EXISTS " + TABLE_INVENTORY + " (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, barcode INTEGER, price REAL, quantity TEXT NOT NULL, category TEXT NOT NULL, image TEXT)";
            db.execSQL(query);

        }

        //Categories table
        {
            String query = "CREATE TABLE IF NOT EXISTS " + TABLE_CATEGORIES + " (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)";
            db.execSQL(query);
        }

        //Sms table
        {
            String query = "CREATE TABLE IF NOT EXISTS " + TABLE_SMS_PERMISSIONS + " (allowed TEXT NOT NULL)";
            db.execSQL(query);

            //Check if there is any record
            @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM " + DBHelper.TABLE_SMS_PERMISSIONS, new String[]{});
            if(cursor.getCount() == 0)
            {
                //insert default value
                ContentValues contentValues = new ContentValues();
                contentValues.put("allowed", "false");
                db.insert(TABLE_SMS_PERMISSIONS, null, contentValues);
            }

        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }
}