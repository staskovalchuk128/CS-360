/*
Copyright 2024 Stanislav Kovalchuk
Inventory app, Version 1.1

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This class is used to generate views for products and categories
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

package com.example.projecttwo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ColorSpace;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import java.io.File;

public class AppViewsGenerator {
    @SuppressLint({"ResourceAsColor", "UseCompatLoadingForDrawables"})
    public static View CreateProductView(InventoryActivity ctx, String id, String name, String barcode, String price, String quantity, String image){

        //Load layout from xml resource
        LayoutInflater inflater = (LayoutInflater)ctx.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.product_item_layout,null);

        ImageView productImageView = view.findViewById(R.id.productImage);

        // Load image for the product
        if(image != null && image.length() > 0) {
            Bitmap productImgBitmap = new ImageSaver(ctx)
                    .setFileName(image)
                    .load();
            if(productImgBitmap != null) {
                productImageView.setImageBitmap(productImgBitmap);
            }
            else { //if not exists, then put placeholder image
                productImageView.setImageDrawable(ctx.getDrawable(android.R.drawable.ic_menu_gallery));
            }
        }
        else {
            //if not exists, then put placeholder image
            productImageView.setImageDrawable(ctx.getDrawable(android.R.drawable.ic_menu_gallery));
        }


        // Fill out views with product information
        TextView productNameView = view.findViewById(R.id.productName);
        productNameView.setText(name);

        TextView productBarcodeView = view.findViewById(R.id.productBarcode);
        productBarcodeView.setText("#: " + barcode);

        TextView productPriceView = view.findViewById(R.id.productPrice);
        productPriceView.setText("$" + price);

        TextView productQuantityView = view.findViewById(R.id.productQuantity);
        productQuantityView.setText(quantity);

        // Setup all the event listeners
        Button btnAddQuantity = view.findViewById(R.id.productBtnAddQuan);
        btnAddQuantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ctx.OnBtnQuickQuantityChangeClick(productQuantityView, id, true);
            }
        });


        Button btnRemoveQuantity = view.findViewById(R.id.productBtnRemoveQuan);
        btnRemoveQuantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ctx.OnBtnQuickQuantityChangeClick(productQuantityView, id, false);
            }
        });

        ImageButton btnEdit = view.findViewById(R.id.btnEditProduct);
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                ctx.ShowEditProductActivity(v, id);
            }
        });

        ImageButton btnDelete = view.findViewById(R.id.btnDeleteProduct);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                ctx.DeleteProduct(v, id);
            }
        });

        return view;
    };


    public static View CreateCategoryView(CategoriesActivity ctx, String id, String name){

        //Load layout from xml resource
        LayoutInflater inflater = (LayoutInflater)ctx.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.category_item_layout,null);

        // Fill out views with category information
        TextView categoryNameView = view.findViewById(R.id.categoryName);
        categoryNameView.setText(name);

        // Setup all the event listeners
        ImageButton btnEdit = view.findViewById(R.id.btnEditCat);
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                ctx.ShowEditCategory(v, id);
            }
        });

        ImageButton btnDelete = view.findViewById(R.id.btnDeleteCat);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                ctx.DeleteCategory(v, id);
            }
        });

        return view;
    };
}
