/*
Copyright 2024 Stanislav Kovalchuk
Inventory app, Version 1.1

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This activity is used to add/edit product
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/


package com.example.projecttwo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.UnsupportedEncodingException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class ProductEditorActivity extends AppCompatActivity {
    private DBManager dbManager;
    private String currentUploadedImageName;
    private String currentProductId = null;
    private ImageSaver imageSaver;
    HashMap<Integer,String> categoriesSpinnerMap = new HashMap<Integer, String>();
    private static final int SELECT_IMAGE_RES_ID = 1228;
    private static final int PERMISSION_REQUEST_READ_FOLDERS = 43212;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_product);

        dbManager = new DBManager(this);
        dbManager.Open();

        imageSaver = new ImageSaver(this);


        //Add categories to spinner
        {
            Spinner categoriesSpinner = findViewById(R.id.editProductCategory);

            // Clear all categories
            categoriesSpinnerMap.clear();

            // Add one default category
            categoriesSpinnerMap.put(0,"-1");

            Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_CATEGORIES, new String[]{});
            int totalItems = cursor.getCount();

            // +1 cause of 1 default category
            String[] spinnerArray = new String[totalItems + 1];
            spinnerArray[0] = "No category";

            for (int i = 1; i <= totalItems; i++) {

                String catId = cursor.getString(0);
                String catName = cursor.getString(1);

                spinnerArray[i] = catName;
                categoriesSpinnerMap.put(i, catId);

                cursor.moveToNext();
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_spinner_item, spinnerArray);
            categoriesSpinner.setAdapter(adapter);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        }


        Intent intent = getIntent();
        currentProductId = intent.getStringExtra("productId");

        //Check if it is opened for editing or adding product
        if(currentProductId == null) {
            ShowAddProduct();
        }
        else{
            ShowEditProduct();
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    public void ShowEditProduct() {
        SetActivityTitle("Edit Product");

        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_INVENTORY + " WHERE id = ?", new String[]{currentProductId});
        if(cursor.getCount() > 0) {
            String productName = cursor.getString(1);
            String productBarcode = cursor.getString(2);
            String productPrice = cursor.getString(3);
            String productQuan = cursor.getString(4);
            String productCategory = cursor.getString(5);
            currentUploadedImageName = cursor.getString(6);

            TextView nameView = (TextView)findViewById(R.id.editItemName);
            TextView priceView = (TextView)findViewById(R.id.editProductPrice);
            TextView barcodeView = (TextView)findViewById(R.id.editProductBarcode);
            TextView quanView = (TextView)findViewById(R.id.editProductQuantity);
            Spinner categoriesSpinner = findViewById(R.id.editProductCategory);

            // Find the index of category in the Spinner
            int categoryKey = 0;
            for(int key: categoriesSpinnerMap.keySet()) {
                if(categoriesSpinnerMap.get(key).equals(productCategory)) {
                    categoryKey = key;
                }
            }

            categoriesSpinner.setSelection(categoryKey);
            nameView.setText(productName);
            priceView.setText(productPrice);
            barcodeView.setText(productBarcode);
            quanView.setText(productQuan);

            // Load image for the product
            if(currentUploadedImageName.length() > 0) {
                Bitmap productImgBitmap = imageSaver.setFileName(currentUploadedImageName).load();
                if(productImgBitmap != null) {
                    SetImageUplodingImageView(productImgBitmap);
                }
                else { //if not exists, then put placeholder image
                    ResetUplodingImageViewToDefault();
                }
            }
            else {
                ResetUplodingImageViewToDefault();
            }

        }
        else{
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Product not found").setPositiveButton(R.string.ok, null).show();
            currentProductId = null;
            ShowAddProduct();
        }

    }

    @SuppressLint("UseCompatLoadingForDrawables")
    public void ShowAddProduct() {
        SetActivityTitle("Add Product");
        ResetUplodingImageViewToDefault();
    }

    public void OnSaveProduct(View v) {
        String productName = ((TextView)findViewById(R.id.editItemName)).getText().toString();
        String productPrice = ((TextView)findViewById(R.id.editProductPrice)).getText().toString();
        String productBarcode = ((TextView)findViewById(R.id.editProductBarcode)).getText().toString();
        String productQuantity = ((TextView)findViewById(R.id.editProductQuantity)).getText().toString();
        String productCategoryId = categoriesSpinnerMap.get(((Spinner)findViewById(R.id.editProductCategory)).getSelectedItemPosition());

        if(productName.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter product name").setPositiveButton(R.string.ok, null).show();
        }
        else if(productPrice.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter product price").setPositiveButton(R.string.ok, null).show();
        }
        else if(productBarcode.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter product barcode").setPositiveButton(R.string.ok, null).show();
        }
        else if(productQuantity.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter product quantity").setPositiveButton(R.string.ok, null).show();
        }
        else {
            Map<String, String> values = new HashMap<String, String>();
            values.put("name", productName);
            values.put("price", productPrice);
            values.put("barcode", productBarcode);
            values.put("quantity", productQuantity);
            values.put("category", productCategoryId);
            values.put("image", currentUploadedImageName);

            if(currentProductId == null){
                dbManager.Insert(DBHelper.TABLE_INVENTORY, values);
            }
            else{
                dbManager.Update(DBHelper.TABLE_INVENTORY, currentProductId, values);
            }
        }

        CloseAddEditProduct(null);
    }

    private void SetActivityTitle(String newTitle){
        TextView title = findViewById(R.id.addEditProductTitle);
        title.setText(newTitle);
    }
    public void CloseAddEditProduct(View v){
        Intent intent = new Intent(this, InventoryActivity.class);
        startActivity(intent);
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private void SetImageUplodingImageView(Bitmap bitmap){
        ImageView productImageView = (ImageView)findViewById(R.id.uploadingProductImageView);
        productImageView.setImageBitmap(bitmap);

        ImageView btnDeleteCurImage = (ImageView)findViewById(R.id.btnDeleteCurrentImage);
        btnDeleteCurImage.setVisibility(View.VISIBLE); // Show delete image btn
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private void ResetUplodingImageViewToDefault(){
        ImageView productImageView = (ImageView)findViewById(R.id.uploadingProductImageView);
        productImageView.setImageDrawable(getDrawable(android.R.drawable.ic_menu_gallery));

        ImageView btnDeleteCurImage = (ImageView)findViewById(R.id.btnDeleteCurrentImage);
        btnDeleteCurImage.setVisibility(View.INVISIBLE); // Hide delete image btn

        currentUploadedImageName = "";
    }

    public void OnDeleteUpdloadedImageClick(View v) {
        if(currentUploadedImageName.length() > 0) {
            imageSaver.setFileName(currentUploadedImageName).deleteFile();
            ResetUplodingImageViewToDefault();
        }
    }

    public void OnChooseImageClick(View v){
        CheckIfStoragePermission();

        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_IMAGE_RES_ID);

    }

    public void CheckIfStoragePermission(){
        if (checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES},
                    PERMISSION_REQUEST_READ_FOLDERS);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SELECT_IMAGE_RES_ID) {
            if(resultCode == RESULT_OK){
                Uri selectedImage = data.getData();
                String[] filePathColumn = {MediaStore.Images.Media.DATA};

                Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
                cursor.moveToFirst();

                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String filePath = cursor.getString(columnIndex);
                cursor.close();


                Bitmap selectedImgBitmap = BitmapFactory.decodeFile(filePath);

                //Create image name, MD5(current time)
                try {
                    currentUploadedImageName = MD5Generator.md5Java(Instant.now().toString()) + ".png";

                    imageSaver.setFileName(currentUploadedImageName).save(selectedImgBitmap);
                    SetImageUplodingImageView(selectedImgBitmap);
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }

            }
        }
    }
}
