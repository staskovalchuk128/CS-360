/*
Copyright 2024 Stanislav Kovalchuk
Inventory app, Version 1.1

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This activity is used to create a user account
This activity can navigate user to "Login" and "Inventory" activities.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

public class CreateAnAccountActivity extends AppCompatActivity {
    private DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_an_account);

        dbManager = new DBManager(this);
        dbManager.Open();
    }

    public void CreateAnAccount(View view) {
        String userName = ((TextView)findViewById(R.id.userNameEditText)).getText().toString();
        String password = ((TextView)findViewById(R.id.userPasswordEditText)).getText().toString();

        if(userName.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter username").setPositiveButton(R.string.ok, null).show();;
        }
        else if(password.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter password").setPositiveButton(R.string.ok, null).show();;
        }
        else
        {
            Map<String, String> values = new HashMap<String, String>();
            values.put("userName", userName);
            values.put("password", password);
            
            dbManager.Insert(DBHelper.TABLE_USERS, values);

            Intent intent = new Intent(this, InventoryActivity.class);
            startActivity(intent);
        }
    }
    public void BackToLoginActivity(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}