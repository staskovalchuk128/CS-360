/*
Copyright 2024 Stanislav Kovalchuk
Inventory app, Version 1.1

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This activity is used to recover user's password
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

public class ForgotPasswordActivity extends AppCompatActivity {

    private DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        dbManager = new DBManager(this);
        dbManager.Open();
    }


    public void SavePassword(View view) {
        String userName = ((TextView)findViewById(R.id.fpUserName)).getText().toString();
        String newPassword = ((TextView)findViewById(R.id.fpNewPassword)).getText().toString();

        if(userName.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter username").setPositiveButton(R.string.ok, null).show();
        }
        else if(newPassword.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter password").setPositiveButton(R.string.ok, null).show();
        }
        else {
            Cursor cursor = dbManager.Fetch("SELECT `id` FROM " + DBHelper.TABLE_USERS + " WHERE userName = ?", new String[]{userName});
            if(cursor.getCount() >= 1) {
                String userId = cursor.getString(0);

                Map<String, String> values = new HashMap<String, String>();
                values.put("password", newPassword);

                dbManager.Update(DBHelper.TABLE_USERS, userId, values);

                new AlertDialog.Builder(this).setTitle("Info").setMessage("Your password has been successfully changed").setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        GoBackToLoginActivity(null);
                    }
                }).show();
            }
            else {
                new AlertDialog.Builder(this).setTitle("Error").setMessage("User with such username not found").setPositiveButton(R.string.ok, null).show();;
            }
        }
    }

    public void GoBackToLoginActivity(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}
