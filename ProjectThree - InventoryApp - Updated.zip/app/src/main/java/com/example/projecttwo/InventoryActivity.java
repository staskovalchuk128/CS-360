/*
Copyright 2024 Stanislav Kovalchuk
Inventory app, Version 1.1

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This activity is used to manage (add/edit/delete) and view products,
search products, and sort products by categories
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/


package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;


public class InventoryActivity extends AppCompatActivity  {
    private DBManager dbManager;
    private LinearLayout inventoryTable;
    private String currentSortByCat = "-1";
    private String currentSearchStr = "";
    private String currentSearchBy = "name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryTable = findViewById(R.id.inventoryTable);

        dbManager = new DBManager(this);
        dbManager.Open();

        RefreshProducts();

        //New enhancement for milestone 5-2
        CreateSortingCategoriesViews();
        AddDefaultEventListeners();
    }

    //New enhancement for milestone 5-2
    private void AddDefaultEventListeners(){
        //Set event listener for searching product
        ((TextView)findViewById(R.id.searchProductTextView)).addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {}
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                OnSearchProduct(s.toString());
            }
        });

        //Set event listener for choosing search by
        ((RadioGroup)findViewById(R.id.productSearchRadioGroup)).setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton btn= (RadioButton)findViewById(checkedId);
                OnChangeSortBy(btn.getText().toString());
            }
        });
    }

    //New enhancement for milestone 5-2
    private void CreateSortingCategoriesViews(){

        TabLayout categoriesTab = findViewById(R.id.sortingCategoriesTab);
        categoriesTab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                currentSortByCat = Integer.toString(tab.getId());
                RefreshProducts();
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });


        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_CATEGORIES, new String[]{});
        int totalCategories = cursor.getCount();
        for (int i = 1; i <= totalCategories; i++) {

            String catId = cursor.getString(0);
            String catName = cursor.getString(1);

            TabLayout.Tab tab = categoriesTab.newTab();
            tab.setId(Integer.parseInt(catId));
            tab.setText(catName);
            categoriesTab.addTab(tab);

            cursor.moveToNext();
        }

    }

    private void ClearLayout(){
        int totalViews = inventoryTable.getChildCount();
        if(totalViews > 0) {
            inventoryTable.removeViews(0,totalViews);
        }
    }

    private void AddProductToTable(String id, String name, String barcode, String price, String quantity, String image) {
        View productView = AppViewsGenerator.CreateProductView(this, id, name, barcode, price, quantity, image);
        inventoryTable.addView(productView);
    }

    public void RefreshProducts(){

        //First clear layout from previous products
        ClearLayout();

        List<String> queryParams = new ArrayList<String>();

        String querySort = "";

        //New enhancement for milestone 5-2
        //If selected any category, extend sql query to sort by categories
        if(!currentSortByCat.equals("-1")) {
            querySort = " AND `category` = ?";
            queryParams.add(currentSortByCat);
        }

        String querySearch = "";

        //New enhancement for milestone 5-2
        //If user typed anything to the search view, extend sql query to search the product
        if(currentSearchStr.trim().length() > 0) {

            //By default search by the name field,
            //if radio button "Barcode" selected, then search by the barcode field
            String searchByField = "name";
            if(currentSearchBy.equals("Barcode")) {
                searchByField = "barcode";
            }
            querySearch = " AND `" + searchByField + "` LIKE ?";
            queryParams.add(currentSearchStr + "%");
        }

        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_INVENTORY +
                " WHERE `id` > 0 " + querySort + querySearch + " ORDER BY `id` DESC", queryParams.toArray(new String[0]));
        int totalProducts = cursor.getCount();
        for (int i = 0; i < totalProducts; i++) {

            String productId = cursor.getString(0);
            String productName = cursor.getString(1);
            String productBarcode = cursor.getString(2);
            String productPrice = cursor.getString(3);
            String productQuan = cursor.getString(4);
            String productImage = cursor.getString(6);

            AddProductToTable(productId, productName, productBarcode, productPrice, productQuan, productImage);
            cursor.moveToNext();
        }

    }

    public void ShowSMSPermissionDialog(View view) {
        SMSDialog dialog = new SMSDialog(this);
        dialog.show(getSupportFragmentManager(), "SMSDialog");
    }

    void NotifyProductHasZeroValue(String productName) {
        //We check if user wants to receive any sms notifications
        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_SMS_PERMISSIONS, new String[]{});
        if(cursor.getCount() > 0) {
            boolean permissionAllowed = cursor.getString(0).equals("true");
            if(permissionAllowed) {
                Toast.makeText(this, "Warning: Product " + productName + " has zero value.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    void DeleteProduct(View v, String productId){
        // Show prompt dialog if user wants delete the product, if he clicks "yes", the we delete the product
        new AlertDialog.Builder(this)
                .setTitle("Deleting product")
                .setMessage("Are you sure you want to delete this product?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dbManager.Delete(DBHelper.TABLE_INVENTORY, productId);
                        RefreshProducts();
                    }
                })
                .setNegativeButton(android.R.string.no, null)
                .show();
    }

    public void OnBtnQuickQuantityChangeClick(View v, String productId, Boolean add) {
        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_INVENTORY + " WHERE id = ?", new String[]{productId});
        if(cursor.getCount() > 0) {
            String productName = cursor.getString(1);
            String currentQuantity = cursor.getString(4);

            //Check if argument add is true then add 1 unit to the quantity
            // if argument add is false then remove one unit from the quantity
            int newQuantity = Integer.parseInt(currentQuantity);
            newQuantity = add ? newQuantity+1 : newQuantity-1;
            String newQuantityAsStr = Integer.toString(newQuantity);

            Map<String, String> values = new HashMap<String, String>();
            values.put("quantity", newQuantityAsStr);

            dbManager.Update(DBHelper.TABLE_INVENTORY, productId, values);

            // if new quantity less or equals zero, the notify the user about it
            if(newQuantity <= 0) {
                NotifyProductHasZeroValue(productName);
            }

            //Update the quantity text view
            ((TextView)v).setText(newQuantityAsStr);
        }

    }

    //New enhancement for milestone 5-2
    public void OnSearchProduct(String searchStr) {
        currentSearchStr = searchStr;
        RefreshProducts();
    }

    //New enhancement for milestone 5-2
    public void OnChangeSortBy(String type) {
        currentSearchBy = type;
        RefreshProducts();
    }

    public void ShowAddProductActivity(View v){
        Intent intent = new Intent(this, ProductEditorActivity.class);
        startActivity(intent);
    }

    public void ShowEditProductActivity(View v, String productId){
        Intent intent = new Intent(this, ProductEditorActivity.class);
        intent.putExtra("productId", productId);
        startActivity(intent);
    }

    //New enhancement for milestone 5-2
    public void OpenCategoriesActivity(View v){
        Intent intent = new Intent(this, CategoriesActivity.class);
        startActivity(intent);
    }

}