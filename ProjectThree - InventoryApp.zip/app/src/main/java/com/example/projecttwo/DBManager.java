package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.Map;

public class DBManager {
    private DBHelper dbHelper;
    private Context context;
    private SQLiteDatabase db;

    public DBManager(Context c) {
        context = c;
    }

    public DBManager Open() throws SQLException{
        dbHelper = new DBHelper(context);
        db = dbHelper.getWritableDatabase();
        return this;
    }

    public void Close() {
        dbHelper.close();
    }
    public void Insert(String tableName, Map<String, String> values){
        ContentValues contentValues = new ContentValues();
        values.forEach(contentValues::put);
        db.insert(tableName, null, contentValues);
    }

    public Cursor Fetch(String request, String[] cols)
    {
        Cursor cursor = db.rawQuery(request, cols);
        if(cursor != null)
        {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public int Update(String tableName, String id, Map<String, String> values)
    {
        ContentValues contentValues = new ContentValues();
        values.forEach(contentValues::put);
        int i = db.update(tableName, contentValues, id.length() > 0 ? "id=" + id : null, null);
        return i;
    }

    public void Delete(String tableName, String id)
    {
        db.delete(tableName, "id=" + id, null);
    }
}
