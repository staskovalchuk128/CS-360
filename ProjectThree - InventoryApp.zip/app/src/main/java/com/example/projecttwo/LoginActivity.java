package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {
    private DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbManager = new DBManager(this);
        dbManager.Open();
    }


    public void OnLoginClick(View view)
    {
        String userName = ((TextView)findViewById(R.id.userNameEditText)).getText().toString();
        String password = ((TextView)findViewById(R.id.userPasswordEditText)).getText().toString();

        if(userName.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter username").setPositiveButton(R.string.ok, null).show();
        }
        else if(password.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter password").setPositiveButton(R.string.ok, null).show();
        }
        else {
            Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_USERS + " WHERE userName = ? AND password = ?", new String[]{userName, password});
            if(cursor.getCount() == 1) {
                Intent intent = new Intent(this, InventoryActivity.class);
                startActivity(intent);
            }
            else {
                new AlertDialog.Builder(this).setTitle("Error").setMessage("Incorrect username/password").setPositiveButton(R.string.ok, null).show();;
            }
        }
    }

    public void OnCreateAccountClick(View view)
    {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

}