package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

import android.R.drawable;
import android.widget.Toast;


public class InventoryActivity extends AppCompatActivity  {
    private DBManager dbManager;
    private TableLayout inventoryTable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryTable = findViewById(R.id.inventoryTable);

        dbManager = new DBManager(this);
        dbManager.Open();


        RefreshItems();

    }

    public void RefreshItems(){

        //Remove prev items
        int totalChilds = inventoryTable.getChildCount();
        if(totalChilds > 1)
        {
            inventoryTable.removeViews(1,totalChilds - 1);
        }

        float density = this.getResources().getDisplayMetrics().density;
        int viewPaddingInPixels = (int)(10 * density);
        int textSizeInPixels = (int)(14 * density);

        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_INVENTORY, new String[]{});
        int totalItems = cursor.getCount();
        for (int i = 0; i < totalItems; i++)
        {

            String itemId = cursor.getString(0);
            String itemDesc = cursor.getString(1);
            String itemQuan = cursor.getString(2);

            TableRow row = new TableRow(this);
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));
            row.setBackground(ContextCompat.getDrawable(this, R.color.white));

            TextView viewDesc = new TextView(this);
            //viewDesc.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            viewDesc.setPadding(viewPaddingInPixels, viewPaddingInPixels, viewPaddingInPixels, viewPaddingInPixels);
            viewDesc.setText(itemDesc);
            viewDesc.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
            viewDesc.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);


            TextView viewQuan = new TextView(this);
            viewQuan.setPadding(viewPaddingInPixels, viewPaddingInPixels, viewPaddingInPixels, viewPaddingInPixels);
            viewQuan.setText(itemQuan);
            viewQuan.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            viewQuan.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);


            LinearLayout btnsWrap = new LinearLayout(this);
            btnsWrap.setOrientation(LinearLayout.HORIZONTAL);

            ImageButton btnEdit = new ImageButton(this);
            btnEdit.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT));
            btnEdit.setBackground(ContextCompat.getDrawable(this, R.color.white));
            btnEdit.setPadding(viewPaddingInPixels,viewPaddingInPixels,viewPaddingInPixels,viewPaddingInPixels);
            btnEdit.setImageDrawable(ContextCompat.getDrawable(this, drawable.ic_menu_edit));
            btnEdit.setImageTintList(ColorStateList.valueOf(getResources().getColor(R.color.appEditColor)));
            btnEdit.setOnClickListener(new ImageButton.OnClickListener(){
                @Override
                public void onClick(View v) {
                    ShowEditItem(v,itemId);
                }
            });

            ImageButton btnDelete = new ImageButton(this);
            btnDelete.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT));
            btnDelete.setBackground(ContextCompat.getDrawable(this, R.color.white));
            btnDelete.setPadding(viewPaddingInPixels,viewPaddingInPixels,viewPaddingInPixels,viewPaddingInPixels);
            btnDelete.setImageDrawable(ContextCompat.getDrawable(this, drawable.ic_menu_delete));
            btnDelete.setImageTintList(ColorStateList.valueOf(getResources().getColor(R.color.appDeleteColor)));
            btnDelete.setOnClickListener(new ImageButton.OnClickListener(){
                @Override
                public void onClick(View v) {
                    DeleteItem(v,itemId);
                }
            });

            btnsWrap.addView(btnEdit);
            btnsWrap.addView(btnDelete);

            row.addView(viewDesc);
            row.addView(viewQuan);
            row.addView(btnsWrap);

            inventoryTable.addView(row);

            cursor.moveToNext();
        }


    }

    public void OnSmsClick(View view)
    {
        SMSDialog dialog = new SMSDialog(this);
        dialog.show(getSupportFragmentManager(), "SMSDialog");
    }


    public void ShowEditItem(View view, String itemId) {

        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_INVENTORY + " WHERE id = ?", new String[]{itemId});
        if(cursor.getCount() > 0) {
            String itemDesc = cursor.getString(1);
            String itemQuan = cursor.getString(2);


            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setCancelable(true);
            dialog.setContentView(R.layout.add_edit_item_dialog);


            TextView title = dialog.findViewById(R.id.addEditDlgTitle);
            TextView descView = (TextView)dialog.findViewById(R.id.editItemDesc);
            TextView quanView = (TextView)dialog.findViewById(R.id.editItemQuantity);

            Button btnSave = dialog.findViewById(R.id.btnSaveItem);
            Button btnCalncel = dialog.findViewById(R.id.btnEditItemCancel);

            title.setText("Edit Item");
            descView.setText(itemDesc);
            quanView.setText(itemQuan);

            btnCalncel.setOnClickListener((v)->{
                dialog.dismiss();
            });

            btnSave.setOnClickListener((v)->{
                OnSaveInventoryItem(dialog, itemId);
                dialog.dismiss();
            });

            dialog.show();

        }
        else{
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Inventory item not found").setPositiveButton(R.string.ok, null).show();
        }




    }

    public void ShowAddNewItem(View view)
    {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.add_edit_item_dialog);

        TextView title = dialog.findViewById(R.id.addEditDlgTitle);
        Button btnSave = dialog.findViewById(R.id.btnSaveItem);
        Button btnCalncel = dialog.findViewById(R.id.btnEditItemCancel);
        title.setText("Add New Item");


        btnCalncel.setOnClickListener((v)->{
            dialog.dismiss();
        });

        btnSave.setOnClickListener((v)->{
            OnSaveInventoryItem(dialog, "");
            dialog.dismiss();
        });

        dialog.show();
    }


    public void OnSaveInventoryItem(Dialog context, String itemId) {
        String itemDesc = ((TextView)context.findViewById(R.id.editItemDesc)).getText().toString();
        String itemQuant = ((TextView)context.findViewById(R.id.editItemQuantity)).getText().toString();

        if(itemDesc.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter item description").setPositiveButton(R.string.ok, null).show();
        }
        else if(itemQuant.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Error").setMessage("Enter item quantity").setPositiveButton(R.string.ok, null).show();
        }
        else {
            Map<String, String> values = new HashMap<String, String>();
            values.put("description", itemDesc);
            values.put("quantity", itemQuant);

            if(itemId.isEmpty()){
                dbManager.Insert(DBHelper.TABLE_INVENTORY, values);
            }
            else{
                dbManager.Update(DBHelper.TABLE_INVENTORY, itemId, values);

                if(Integer.parseInt(itemQuant) <= 0)
                {
                    NotifyZeroValueItem(itemDesc);
                }

            }

            RefreshItems();
        }
    }

    void NotifyZeroValueItem(String itemDesc)
    {
        Cursor cursor = dbManager.Fetch("SELECT * FROM " + DBHelper.TABLE_SMS_PERMISSIONS, new String[]{});
        if(cursor.getCount() > 0)
        {
            boolean permissionAllowed = cursor.getString(0).equals("true");
            if(permissionAllowed)
            {
                Toast.makeText(this, "Warning: Item" + itemDesc + " has zero value.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }


    void DeleteItem(View v, String itemId){
        dbManager.Delete(DBHelper.TABLE_INVENTORY, itemId);
        RefreshItems();
    }
}