package com.example.projecttwo;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashMap;
import java.util.Map;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "projectThreeDB";

    private static final int DB_VERSION = 2;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_INVENTORY = "inventory";
    public static final String TABLE_SMS_PERMISSIONS = "smsPermissions";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Users table
        {
            String query = "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, password TEXT NOT NULL)";
            db.execSQL(query);
        }

        //Inventory table
        {
            String query = "CREATE TABLE IF NOT EXISTS " + TABLE_INVENTORY + " (id INTEGER PRIMARY KEY AUTOINCREMENT, description TEXT NOT NULL, quantity TEXT NOT NULL)";
            db.execSQL(query);
        }

        //Sms table
        {
            String query = "CREATE TABLE IF NOT EXISTS " + TABLE_SMS_PERMISSIONS + " (allowed TEXT NOT NULL)";
            db.execSQL(query);

            //insert default value
            ContentValues contentValues = new ContentValues();
            contentValues.put("allowed", "false");
            db.insert(TABLE_SMS_PERMISSIONS, null, contentValues);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }
}